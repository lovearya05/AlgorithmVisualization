import React from "react";
import "./Circle.css";

export default function Circle({ element, length }) {
	return <div className="Circle">{element}</div>;
}
