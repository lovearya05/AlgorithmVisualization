import React from "react";
import "./Image.css";
import Img from "./images/arrowImg.png";

export default function Image() {
	return <img className="Image" src={Img} alt="arrow" />;
}
