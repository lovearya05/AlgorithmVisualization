import React from "react";
import {NavBar} from "./components/NavBar.jsx"
// import { Footer } from "./components/Footer";
import { Controller } from "./components/Controller";
// import { AlgoDisplay } from "./components/AlgoDisplay";



function App() {
  return (
   <>
     <NavBar/>
     <Controller />
     {/* <AlgoDisplay/> */}
   </>
  );
}

export default App;